package com.example.foodorderingapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class PasswordRecovery : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var otpEditText: EditText
    private lateinit var sendOTPButton: Button
    private lateinit var verifyButton: Button
    private lateinit var otpLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_password_recovery)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        emailEditText = findViewById(R.id.emailField)
        otpEditText = findViewById(R.id.OTPField)
        sendOTPButton = findViewById(R.id.sendOTPButton)
        verifyButton = findViewById(R.id.verifyButton)
        otpLayout = findViewById(R.id.otpLayout)

        // Initially hide the OTP layout
        otpLayout.visibility = View.GONE

        // Send OTP button click listener
        sendOTPButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            if (email.isNotEmpty()) {
                sendOTP(email)
            } else {
                Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show()
            }
        }

        // Verify button click listener
        verifyButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val otp = otpEditText.text.toString().trim()
            if (email.isNotEmpty() && otp.isNotEmpty()) {
                verifyOTP(email, otp)
            } else {
                Toast.makeText(this, "Please enter your email and OTP", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendOTP(email: String) {
        val request = OTPRequest(email)
        RetrofitClient.instance.sendOTP(request).enqueue(object : Callback<OTPResponse> {
            override fun onResponse(call: Call<OTPResponse>, response: Response<OTPResponse>) {
                if (response.isSuccessful) {
                    val otpResponse = response.body()
                    if (otpResponse != null) {
                        // Show the OTP layout
                        otpLayout.visibility = View.VISIBLE
                        Toast.makeText(this@PasswordRecovery, otpResponse.message, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@PasswordRecovery, "Failed to parse response", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@PasswordRecovery, "Failed to send OTP: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<OTPResponse>, t: Throwable) {
                Toast.makeText(this@PasswordRecovery, "Failed to send OTP: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun verifyOTP(email: String, otp: String) {
        val request = VerifyOTPRequest(email, otp)
        RetrofitClient.instance.verifyOTP(request).enqueue(object : Callback<OTPResponse> {
            override fun onResponse(call: Call<OTPResponse>, response: Response<OTPResponse>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@PasswordRecovery, "OTP verified successfully!", Toast.LENGTH_SHORT).show()
                    // Navigate to the next screen (e.g., password reset screen)
                    val intent = Intent(this@PasswordRecovery, PasswordReset::class.java)
                    intent.putExtra("email", email)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@PasswordRecovery, "Failed to verify OTP: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<OTPResponse>, t: Throwable) {
                Toast.makeText(this@PasswordRecovery, "Failed to verify OTP: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}