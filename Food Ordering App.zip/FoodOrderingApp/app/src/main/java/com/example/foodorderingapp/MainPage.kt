package com.example.foodorderingapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val addBBQButton = findViewById<Button>(R.id.addButtonBBQ)
        addBBQButton.setOnClickListener {
            val item = CartItem(
                name = "Pork Barbeque",
                description = "Delicious grilled savory pork BBQ",
                price = 200.0,
                imageResId = R.drawable.pork_barbeque,
                quantity = 1
            )
            CartManager.addItem(item)
        }

        val addAdoboButton = findViewById<Button>(R.id.addButtonAdobo)
        addAdoboButton.setOnClickListener {
            val item = CartItem(
                name = "Pork Adobo",
                description = "Traditional Pork Adobo",
                price = 225.0,
                imageResId = R.drawable.pork_adobo,
                quantity = 1
            )
            CartManager.addItem(item)
        }

        val addLechonButton = findViewById<Button>(R.id.addButtonLechon)
        addLechonButton.setOnClickListener {
            val item = CartItem(
                name = "Pork Barbeque",
                description = "Crispy & tender fried pork belly",
                price = 275.0,
                imageResId = R.drawable.lechon_kawali,
                quantity = 1
            )
            CartManager.addItem(item)
        }

        val cartIconButton: ImageView = findViewById(R.id.cartIcon)!!
        cartIconButton.setOnClickListener {
            val cartIntent = Intent(this, CartActivity::class.java)
            startActivity(cartIntent)
        }
    }
}