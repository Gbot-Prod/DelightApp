package com.example.foodorderingapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.util.Log

class RegisterPage : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etPasswordConfirmation: EditText
    private lateinit var btnRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_page)

        etUsername = findViewById(R.id.usernameField)
        etEmail = findViewById(R.id.emailField)
        etPassword = findViewById(R.id.passwordField)
        etPasswordConfirmation =  findViewById(R.id.confirmPasswordField)
        btnRegister = findViewById(R.id.loginButton)

        btnRegister.setOnClickListener {
            val username = etUsername.text.toString()
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()
            val passwordConfirmation = etPasswordConfirmation.text.toString()

            if (password == passwordConfirmation) {
                if (username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                    registerUser(username, email, password)
                } else {
                    Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Passwords must match", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun registerUser(username: String, email: String, password: String) {
        val user = User(username, email, password)
        val call = RetrofitClient.instance.registerUser(user)

        call.enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    Log.d("RegisterPage", "Registration successful: ${response.body()?.string()}")
                    Toast.makeText(this@RegisterPage, "Registration successful", Toast.LENGTH_SHORT).show()
                } else {
                    Log.e("RegisterPage", "Registration failed: ${response.errorBody()?.string()}")
                    Toast.makeText(this@RegisterPage, "Registration failed", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Log.e("RegisterPage", "Network error: ${t.message}")
                Toast.makeText(this@RegisterPage, "Network error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}