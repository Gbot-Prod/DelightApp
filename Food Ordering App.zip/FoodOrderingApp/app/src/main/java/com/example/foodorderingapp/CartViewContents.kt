package com.example.foodorderingapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData

class CartViewModel(application: Application) : AndroidViewModel(application) {
    val cartItems = MutableLiveData<MutableList<CartItem>>()

    init {
        cartItems.value = mutableListOf()
    }

    fun addItem(item: CartItem) {
        val currentList = cartItems.value ?: mutableListOf()
        val existingItem = currentList.find { it.name == item.name }

        if (existingItem != null) {
            // If the item already exists, increment its quantity
            existingItem.quantity += item.quantity
        } else {
            // Otherwise, add the new item to the cart
            currentList.add(item)
        }

        cartItems.value = currentList
    }
}

data class CartItem(
    val name: String,
    val description: String,
    val price: Double,
    val imageResId: Int,
    var quantity: Int
)