package com.example.foodorderingapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginPage : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        etUsername = findViewById(R.id.usernameField)
        etPassword = findViewById(R.id.passwordField)
        btnLogin = findViewById(R.id.loginButton)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()
            val loginSuccess = Intent(this, MainPage::class.java)

            if (username.isNotEmpty() && password.isNotEmpty()) {
                loginUser(username, password)
                startActivity(loginSuccess)
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loginUser(username: String, password: String) {
        val user = User(username, password)
        val call = RetrofitClient.instance.loginUser(user)

        call.enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    Toast.makeText(this@LoginPage, "Login successful", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@LoginPage, "Invalid username or password", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Toast.makeText(this@LoginPage, "Network error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}