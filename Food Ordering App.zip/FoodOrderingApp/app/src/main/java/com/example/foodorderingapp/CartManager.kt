package com.example.foodorderingapp

object CartManager {
    private val cartItems = mutableListOf<CartItem>()

    fun addItem(item: CartItem) {
        val existingItem = cartItems.find { it.name == item.name }

        if (existingItem != null) {
            // If the item already exists, increment its quantity
            existingItem.quantity += item.quantity
        } else {
            // Otherwise, add the new item to the cart
            cartItems.add(item)
        }
    }

    fun getCartItems(): List<CartItem> {
        return cartItems
    }

    fun clearCart() {
        cartItems.clear()
    }
}