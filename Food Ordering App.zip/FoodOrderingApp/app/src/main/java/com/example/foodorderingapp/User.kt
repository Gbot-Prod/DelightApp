package com.example.foodorderingapp

data class User(
    val username: String,
    val password: String
)