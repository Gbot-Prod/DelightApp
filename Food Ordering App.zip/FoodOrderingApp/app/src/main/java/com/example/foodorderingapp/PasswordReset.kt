package com.example.foodorderingapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PasswordReset : AppCompatActivity() {

    private lateinit var newPasswordField: EditText
    private lateinit var confirmPasswordField: EditText
    private lateinit var resetPasswordButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_password_reset)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        newPasswordField = findViewById(R.id.newPasswordField)
        confirmPasswordField = findViewById(R.id.confirmPasswordField)
        resetPasswordButton = findViewById(R.id.passwordUpdateButton)

        val email = intent.getStringExtra("email") ?: ""

        resetPasswordButton.setOnClickListener {
            val newPassword = newPasswordField.text.toString().trim()
            val confirmPassword = confirmPasswordField.text.toString().trim()

            if (newPassword.isNotEmpty() && confirmPassword.isNotEmpty()) {
                if (newPassword == confirmPassword) {
                    resetPassword(email, newPassword, confirmPassword)
                } else {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun resetPassword(email: String, newPassword: String, confirmPassword: String) {
        val request = ResetPasswordRequest(email, newPassword, confirmPassword)
        RetrofitClient.instance.resetPassword(request).enqueue(object : Callback<OTPResponse> {
            override fun onResponse(call: Call<OTPResponse>, response: Response<OTPResponse>) {
                if (response.isSuccessful) {
                    val resetResponse = response.body()
                    if (resetResponse != null) {
                        Toast.makeText(this@PasswordReset, resetResponse.message, Toast.LENGTH_SHORT).show()
                        // Navigate back to the login screen or main screen
                        finish()
                    } else {
                        Toast.makeText(this@PasswordReset, "Failed to parse response", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@PasswordReset, "Failed to reset password: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<OTPResponse>, t: Throwable) {
                Toast.makeText(this@PasswordReset, "Failed to reset password: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}