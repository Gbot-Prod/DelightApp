package com.example.foodorderingapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer

class CartActivity : AppCompatActivity() {

    private lateinit var foodItemsContainer: LinearLayout
    private val cartViewModel: CartViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        foodItemsContainer = findViewById(R.id.foodItemsContainer)

        cartViewModel.cartItems.observe(this) { items ->
            updateCartUI(items)
        }

        val returnButton = findViewById<ImageView>(R.id.returnButton)
        returnButton.setOnClickListener {
            val returnIntent = Intent (this, MainPage::class.java)
            startActivity(returnIntent)
        }

        val clearAllButton = findViewById<Button>(R.id.clearAllButton)
        clearAllButton.setOnClickListener {
        }
    }

    private fun updateCartUI(items: List<CartItem>) {
        foodItemsContainer.removeAllViews()

        for (item in items) {
            addProductToCart(item)
        }
    }

    private fun addProductToCart(item: CartItem) {
        // Inflate the product card layout
        val inflater = LayoutInflater.from(this)
        val productCard = inflater.inflate(R.layout.product_card_1, foodItemsContainer, false)

        // Bind data to the views
        val productName: TextView = productCard.findViewById(R.id.productName)
        val productDescription: TextView = productCard.findViewById(R.id.productDescription)
        val productPrice: TextView = productCard.findViewById(R.id.productPrice)
        val foodImage: ImageView = productCard.findViewById(R.id.foodImage)
        val productQuantity: TextView = productCard.findViewById(R.id.productQuantity)

        productName.text = item.name
        productDescription.text = item.description
        productPrice.text = "₱${"%.2f".format(item.price)}"
        foodImage.setImageResource(item.imageResId)
        productQuantity.text = "Qty: ${item.quantity}"

        // Add the product card to the container
        foodItemsContainer.addView(productCard)
    }
}