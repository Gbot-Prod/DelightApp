package com.example.foodorderingapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class CartActivity : AppCompatActivity() {

    private lateinit var foodItemsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        foodItemsContainer = findViewById(R.id.foodItemsContainer)

        // Retrieve cart items from CartManager
        val cartItems = CartManager.getCartItems()

        // Update the UI with cart items
        updateCartUI(cartItems)

        val returnButton = findViewById<ImageView>(R.id.returnButton)
        returnButton.setOnClickListener {
            val returnIntent = Intent(this, MainPage::class.java)
            startActivity(returnIntent)
        }

        val clearAllButton = findViewById<Button>(R.id.clearAllButton)
        clearAllButton.setOnClickListener {
            // Clear the cart
            CartManager.clearCart()
            foodItemsContainer.removeAllViews()
            Toast.makeText(this, "Cart cleared", Toast.LENGTH_SHORT).show()
        }

        // Add a "Checkout" button
        val checkoutButton: Button = findViewById(R.id.orderButton)
        checkoutButton.setOnClickListener {
            val userId = getCurrentUserId() // Replace with the logged-in user's ID

            // Send each item in the cart to the backend
            for (item in cartItems) {
                val order = Order(
                    id = userId,
                    product_name = item.name,
                    product_price = item.price,
                    quantity = item.quantity
                )
                sendOrderToBackend(order)
            }

            // Clear the cart after checkout
            CartManager.clearCart()
            foodItemsContainer.removeAllViews()
            Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateCartUI(items: List<CartItem>) {
        foodItemsContainer.removeAllViews()

        for (item in items) {
            val inflater = LayoutInflater.from(this)
            val productCard = inflater.inflate(R.layout.product_card_1, foodItemsContainer, false)

            val productName: TextView = productCard.findViewById(R.id.productName)
            val productDescription: TextView = productCard.findViewById(R.id.productDescription)
            val productPrice: TextView = productCard.findViewById(R.id.productPrice)
            val foodImage: ImageView = productCard.findViewById(R.id.foodImage)
            val productQuantity: TextView = productCard.findViewById(R.id.productQuantity)

            productName.text = item.name
            productDescription.text = item.description
            productPrice.text = "₱${"%.2f".format(item.price)}"
            foodImage.setImageResource(item.imageResId)
            productQuantity.text = "Qty: ${item.quantity}"

            foodItemsContainer.addView(productCard)
        }
    }

    private fun sendOrderToBackend(order: Order) {
        val retrofit = Retrofit.Builder()
            .baseUrl("http://192.168.0.150/delight/") // Replace with your backend URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(ApiService::class.java)
        val call = service.placeOrder(order)

        call.enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                if (response.isSuccessful) {
                    Log.d("Order", "Order placed successfully!")
                } else {
                    Log.e("Order", "Failed to place order")
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                Log.e("Order", "Error: ${t.message}")
            }
        })
    }

    private fun getCurrentUserId(): Int {
        // Replace this with your logic to get the logged-in user's ID
        // For example, you can retrieve it from SharedPreferences or your authentication system
        return 1 // Placeholder for the user ID
    }
}