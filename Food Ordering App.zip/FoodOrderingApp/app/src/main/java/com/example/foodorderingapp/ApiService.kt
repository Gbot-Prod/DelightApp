package com.example.foodorderingapp

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("register.php") // Replace with your register endpoint
    fun registerUser(@Body user: User): Call<ResponseBody>

    @POST("login.php") // Replace with your login endpoint
    fun loginUser(@Body user: User): Call<ResponseBody>
}