package com.example.foodorderingapp

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("register.php")
    fun registerUser(@Body user: User): Call<ResponseBody>

    @POST("login.php")
    fun loginUser(@Body user: User): Call<ResponseBody>

    @POST("orders.php")
    fun placeOrder(@Body order: Order): Call<ResponseBody>

    @POST("otp.php")
    fun sendOTP(@Body request: OTPRequest): Call<OTPResponse>

    @POST("otp.php")
    fun verifyOTP(@Body request: VerifyOTPRequest): Call<OTPResponse>

    @POST("reset_password.php")
    fun resetPassword(@Body request: ResetPasswordRequest): Call<OTPResponse>
}