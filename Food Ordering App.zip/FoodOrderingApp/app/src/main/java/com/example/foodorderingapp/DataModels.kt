package com.example.foodorderingapp

data class User(
    val username: String,
    val email: String? = null,
    val password: String
)

data class Order(
    val id: Int,
    val product_name: String,
    val product_price: Double,
    val quantity: Int
)

data class CartItem(
    val name: String,
    val description: String,
    val price: Double,
    val imageResId: Int,
    var quantity: Int
)

data class OTPRequest(
    val email: String
)

data class VerifyOTPRequest(
    val email: String,
    val otp: String
)

data class OTPResponse(
    val status: String,
    val message: String
)

data class ResetPasswordRequest(
    val email: String,
    val newPassword: String,
    val confirmPassword: String
)